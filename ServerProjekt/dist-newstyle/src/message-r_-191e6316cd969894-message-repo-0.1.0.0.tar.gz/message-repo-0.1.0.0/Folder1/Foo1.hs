module Folder1.Foo1 where
    foo = print "foo"