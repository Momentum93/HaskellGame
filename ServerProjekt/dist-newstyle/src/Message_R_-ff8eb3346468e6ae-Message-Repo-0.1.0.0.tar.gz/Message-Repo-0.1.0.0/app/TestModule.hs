module TestModule where

    foo = print "TestModule: foo"